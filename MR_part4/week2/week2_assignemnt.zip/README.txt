Sampling-Based Planning

A Rapidly exploring Random Trees (RRT) is used to create a path